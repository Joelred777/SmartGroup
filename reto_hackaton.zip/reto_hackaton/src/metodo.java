/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author joelg
 */
class metodo {
    private String cadena;
   private double resultado;
   private boolean resta; 
   
   
   public metodo(){
       cadena="";
       resta=false;
      
   
     
   }
   public String concatenamiento(String cadena){
   
       this.cadena=this.cadena+cadena;
       return this.cadena;
       
   
   }
   public void resta(String cadena){
   
       this.resultado=Double.parseDouble(cadena);
       resta=true;
       this.cadena="";
   
   }
   public double resultado(String numero){
   
       if(resta==true){
           
       resultado=resultado-Double.parseDouble(numero);
       
       }
   resta=false;
   return resultado;
   }
   
   }
   



